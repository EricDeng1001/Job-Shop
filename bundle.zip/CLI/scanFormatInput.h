//作者:邓智豪
#ifndef __SCANFORMATINPUT__H__
#define __SCANFORMATINPUT__H__

#include "../Algorithm/decribeTable.h"

DescribeTable scanFormatInput();

#endif
