//作者:邓智豪
#ifndef __ALGORITHM_H__
#define __ALGORITHM_H__

#include "./gene.h"
#include "./crossover.h"
#include "./mutate.h"
#include "./decode.h"

#endif
