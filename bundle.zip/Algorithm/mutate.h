//作者:邓智豪
#ifndef __MUTATE__H__
#define __MUTATE__H__
#include "./gene.h"

Gene mutate( Gene origin );

#endif
